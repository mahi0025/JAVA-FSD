package Multithreading;

public class thread extends Thread {
	
	public void run() {
		System.out.println("thread Started");
	}
	
	public static void main(String[] args) {
		
		thread t1= new thread();
		thread t2= new thread();
		
		t1.start();
		t2.start();
	}

}