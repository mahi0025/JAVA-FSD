package typecasting;

public class implicitexplicit {
	
          public static void main(String [] args) {
		
		double a= 23.67;
		
		
		int b=(int) a;  
		
		System.out.println("Converted Double "+a+" to int "+b);
		
		byte c=10;
		System.out.println("Byte: "+c);
		
		short d=52;
		System.out.println("Byte to Short Conversion: "+d);
		
		int e =85;
		System.out.println("Short to Int Conversion: "+e);
		
		int f=b;
		System.out.println("Byte to Int Conversion: "+f);
		
		float g=d;
		System.out.println("Int to Float Conversion: "+g);
		
		double h=e;
		System.out.println("Float to double Conversion: "+h);
		
		System.out.println("Int to double Conversion: "+g);
		
		

    }
}
