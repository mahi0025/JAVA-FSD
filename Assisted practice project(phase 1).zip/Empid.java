package constructor;

public class Empid {
	
	int empId;
	String empName;
	String department;
	float salary;
	

	public Empid() {
		empId=164;
		empName="mahi";
		department="IT";
		salary=35000;
	}
	

	public Empid(int empId,String empName,String department,float salary) {
		this.empId=empId;
		this.empName=empName;
		this.department=department;
		this.salary=salary;
	}
	
	public void display() {
		System.out.println("Id: "+empId);
		System.out.println("Name: "+empName);
		System.out.println("Department: "+department);
		System.out.println("Salary: "+salary);
		System.out.println();
		
	}
	
	public static void main(String[] args) {
		
		Empid e= new Empid();
		e.display();
		
		 
	
	}

	
}


