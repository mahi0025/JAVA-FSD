package map;

import java.util.HashMap;
import java.util.TreeMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;

public class hashmap {
	
		public static void main(String[] args) {
			
			HashMap<Integer,String> hm=new HashMap<Integer,String>();      
		      hm.put(1,"Mahi");    
		      hm.put(2,"santhosh");    
		      hm.put(3,"kanna");   
		       
		      System.out.println("\nThe elements of Hashmap are ");  
		      for (Iterator<Entry<Integer, String>> iterator = hm.entrySet().iterator(); iterator.hasNext();) {
				Entry<Integer, String> m = iterator.next();
				System.out.println(m.getKey()+" "+m.getValue());
			}
		    Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
		      
		      ht.put(4,"xfyf");  
		      ht.put(5,"tuft");  
		      ht.put(6,"ctutitf");  
		      ht.put(7,"ctuxcu");  

		      System.out.println("\nThe elements of Table are ");  
		      for (Iterator<Entry<Integer, String>> iterator = ht.entrySet().iterator(); iterator.hasNext();) {
				Entry<Integer, String> n = iterator.next();
				System.out.println(n.getKey()+" "+n.getValue());
			}
		      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(8,"755");    
		      map.put(9,"454");    
		      map.put(10,"854");       
		      
		      System.out.println("\nThe elements of Map are ");  
		      for (Iterator<Entry<Integer, String>> iterator = map.entrySet().iterator(); iterator.hasNext();) {
				Entry<Integer, String> l = iterator.next();
				System.out.println(l.getKey()+" "+l.getValue());
			}    
		      
		   }  
	}




